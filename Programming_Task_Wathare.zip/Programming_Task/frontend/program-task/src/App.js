import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';
import Chart from 'chart.js/auto';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

function App() {
  const [data, setData] = useState([]);
  const [summary, setSummary] = useState({});
  const [startTime, setStartTime] = useState(null);
  const [endTime, setEndTime] = useState(null);

  const formatDate = (date) => {
    return date ? date.toISOString().slice(0, -5) + 'Z' : '';
  };

  // const fetchData = async () => {
  //   try {
  //     const response = await axios.get(`http://localhost:5000/data?start_time=${formatDate(startTime)}&end_time=${formatDate(endTime)}`);
  //     setData(response.data.data);
  //     setSummary(response.data.summary);
  //   } catch (err) {
  //     console.error(err);
  //     // Handle errors
  //   }
  // };

  // const fetchData = async () => {
  //   try {
  //     const formattedStartTime = formatDate(startTime);
  //     const formattedEndTime = formatDate(endTime);
  //     const response = await axios.get(`http://localhost:5000/data?start_time=${formattedStartTime}&end_time=${formattedEndTime}`);
  //     setData(response.data.data);
  //     setSummary(response.data.summary);
  //   } catch (err) {
  //     console.error(err);
  //     // Handle errors
  //   }
  // };

  const fetchData = async () => {
    try {
      const startTimeUTC = startTime ? new Date(startTime.getTime() - startTime.getTimezoneOffset() * 60000).toISOString().slice(0, -5) + 'Z' : '';
      const endTimeUTC = endTime ? new Date(endTime.getTime() - endTime.getTimezoneOffset() * 60000).toISOString().slice(0, -5) + 'Z' : '';

      const response = await axios.get(`http://localhost:5000/data?start_time=${startTimeUTC}&end_time=${endTimeUTC}`);
        setData(response.data.data);
      setSummary(response.data.summary);
    } catch (err) {
      console.error(err);
      // Handle errors
    }
  };

  useEffect(() => {
    fetchData();
  }, [startTime, endTime]);

  const chartData = {
    labels: data.map(d => d.ts),
    datasets: [
      {
        label: 'Machine Status',
        data: data.map(d => d.machine_status),
        fill: false,
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1,
      },
    ],
  };

  const handleButtonClick = (duration) => {
    const currentTime = new Date();
    setStartTime(new Date(currentTime.getTime() - duration * 60 * 60 * 1000)); // Subtract duration hours from current time
    setEndTime(currentTime);
    fetchData();
  };
  return (
    <div>
      <hr/>
      <div className='container'>
        <input className="text"></input>
      <button className='btn btn-dark' onClick={() => handleButtonClick(1)}>1hr</button>
      <button className='btn btn-primary' onClick={() => handleButtonClick(8)}>8hr</button>
      <button className='btn btn-secondary' onClick={() => handleButtonClick(24)}>24hr</button>
      </div>
      <hr/>
      <Line data={chartData} />
      <table>
        <thead>
          <tr>
            <th>Number of Ones</th>
            <th>Number of Zeros</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{summary.numOnes}</td>
            <td>{summary.numZeros}</td>
          </tr>
        </tbody>
      </table>
      <button onClick={fetchData}>Fetch Data</button>
      <div>
        <label>Start Time:</label>
        <DatePicker
          selected={startTime}
          onChange={(date) => setStartTime(date)}
          showTimeSelect
          timeFormat="HH:mm:ss"
          timeIntervals={15}
          dateFormat="yyyy-MM-dd'T'HH:mm:ss'Z'"
        />
      </div>
      <div>
        <label>End Time:</label>
        <DatePicker
          selected={endTime}
          onChange={(date) => setEndTime(date)}
          showTimeSelect
          timeFormat="HH:mm:ss"
          timeIntervals={15}
          dateFormat="yyyy-MM-dd'T'HH:mm:ss'Z'"
        />
      </div>
    </div>
  );
}

export default App;