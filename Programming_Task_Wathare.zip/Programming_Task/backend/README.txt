open terminal 
1. npm init -y
2. npm i -g nodemon
3. npm i express
4. npm i cors
5. npm i mongoose